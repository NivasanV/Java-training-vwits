interface Printable{
    void print();
}
