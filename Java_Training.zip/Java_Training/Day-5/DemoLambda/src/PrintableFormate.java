interface PrintableFormate{
    void print(String str);
}
