@FunctionalInterface
interface Condition{
    boolean check(String city);
}