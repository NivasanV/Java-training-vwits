Cohesion
	-It is the degree to which class has one single focused responsibility.
	-It is strongly recommended to every class must have focused responsibility.
	-It is known as high cohesion.

For Creating file Architecture *******
	-To help our application to(Read, Insert, Update, Delete) talk to underline data store(in memory/databases).
	-We need to create separate class which is solely responsible for this functionality.
	-In java world this class is known as DAO(Data Access Object).
	-This is pattern followed by developers.
	
-Layered Architechure design i sthe most common design patter used in industry.
-the idea behind this pattern os classes with similla functionalities are grouped or organized in a single unit.
Every unit is called as 