Method Reference
	1-This Feature is added in Java 8.
	2-It is the Shorthand way of writing Lambda expression.
	3-As name specifies it is used to refer to a method matching with the signature of
	  Functional Interface methid.
	4-
	