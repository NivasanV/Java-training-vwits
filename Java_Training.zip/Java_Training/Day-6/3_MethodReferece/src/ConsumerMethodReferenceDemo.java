import java.util.function.Consumer;

public class ConsumerMethodReferenceDemo {
	
	static void display(String data) {
		System.out.println(data);
	}
	
	void show(String data) {
		
		System.out.println(data);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Consumer<String> c = str -> System.out.println(str);
		// in Following line we are using reference instead of writing 
		// Line 12 and Line 15 are logically same but line 15 shorthand way of writing
		// of writing Lambda expression
		Consumer<String> c1 = ConsumerMethodReferenceDemo::display;
		ConsumerMethodReferenceDemo obj = new ConsumerMethodReferenceDemo();
		Consumer<String> c2 = obj::show;
		
		c.accept("Python");
		c1.accept("java");
		c2.accept("String");
		
		Consumer<String> c3 = System.out::println;
		c3.accept("c++");
		
	}
}
