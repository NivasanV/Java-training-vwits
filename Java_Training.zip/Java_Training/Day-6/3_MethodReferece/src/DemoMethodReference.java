
interface Printable{
	void print();
}

public class DemoMethodReference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Printable p = System.out::println;
		p.print();
	}

}
