
public class Printable {
	
	void print();
	
	
	
	default void color() {
		
	}
}
