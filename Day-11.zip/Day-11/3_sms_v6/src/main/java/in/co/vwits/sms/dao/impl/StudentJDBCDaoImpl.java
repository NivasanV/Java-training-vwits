package in.co.vwits.sms.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import in.co.vwits.sms.dao.StudentDao;
import in.co.vwits.sms.model.Student;

public class StudentJDBCDaoImpl implements StudentDao{
	//Save 
	public int save(Student s) { 
		try (Connection con =
			DriverManager.getConnection("jdbc:mysql://localhost:3306/student_db","root",
					"root");
		PreparedStatement pstmt =con.prepareStatement("INSERT INTO tbl_student VALUES(?,?,?,?,?)");) {
		pstmt.setInt(1, s.getRollno()); 
		pstmt.setString(2,s.getName());
		pstmt.setDouble(3,s.getPercentage());
		pstmt.setInt(4,s.getNumberOfAttempts());
		pstmt.setDate(5,Date.valueOf(s.getDateOfBirth()));
		int noOfRowsUpdated = pstmt.executeUpdate();// firing query...
		

		//System.out.println("No of records updated are "+ noOfRowSpaceUpdated); 
		return noOfRowsUpdated;
		}
	catch (SQLException e) { e.printStackTrace(); }
     return 0;
	}
	
	//Delete
	public void deleteByRollno(int rollno) {
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_db","root","root");
			PreparedStatement pstmt = con.prepareStatement("DELETE FROM tbl_student WHERE rollno = ?"); 
				){
			// Before actually firing the query we must set the values for all the ? marks
			pstmt.setInt(1, rollno);
			int noOfRowsUpdated = pstmt.executeUpdate(); // firing query
			System.out.println("No of records affected are: "+ noOfRowsUpdated);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//Update
	public void updateByRollno(int rollno, double modifiedPercentage) {
		try 
		(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_db","root","root");
		 PreparedStatement pstmt = con.prepareStatement("UPDATE tbl_student SET percentage =? WHERE rollno =?");)
		 {
	    pstmt.setDouble(1,modifiedPercentage);
        pstmt.setInt(2,rollno);
      
              
        int noOfRowSpaceUpdated = pstmt.executeUpdate();// firing query...

        System.out.println("No of records updated are "+ noOfRowSpaceUpdated);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
}
	
	
	//Find by rollno
	
	public Optional<Student> findByRollno(int rollno)
	{
		try 
		(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_db","root","root");
	PreparedStatement pstmt = con.prepareStatement("SELECT * FROM tbl_student WHERE rollno= ?");)
		
		{Student foundStudent = new Student();
         pstmt.setInt(1, rollno);
       
        ResultSet rs = pstmt.executeQuery();//firing query- 
        if(rs.next()) {                          //this method returns true if any 
                                                 //records are present
        	foundStudent.setRollno(rs.getInt(1));
        	foundStudent.setName(rs.getString(2));
        	foundStudent.setPercentage(rs.getDouble(3));
        	foundStudent.setNumberOfAttempts(rs.getInt(4));
        	foundStudent.setDateOfBirth(rs.getDate(5).toLocalDate());
    	
        }
        return Optional.of(foundStudent);
       
	} catch (SQLException e) {
		e.printStackTrace();
	}
	/*
	 * finally { try { pstmt.close(); con.close(); }catch(SQL Exception e) {
	 * e.printStackTrace(); } }
	 */
		return Optional.empty();
		
	}
	//Find All
	public List<Student> findAll(){
		List<Student> students= new ArrayList<>();
		try 
		(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_db","root","root");
				PreparedStatement pstmt = con.prepareStatement("SELECT * FROM tbl_student ");)
		{
			
			ResultSet rs = pstmt.executeQuery();//firing query- 
			while(rs.next()) {                          //this method returns true if any 
				//records are present
				Student foundStudent=new Student();
				foundStudent.setRollno(rs.getInt(1));
	        	foundStudent.setName(rs.getString(2));
	        	foundStudent.setPercentage(rs.getDouble(3));
	        	foundStudent.setNumberOfAttempts(rs.getInt(4));
	        	foundStudent.setDateOfBirth(rs.getDate(5).toLocalDate());
				students.add(foundStudent);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return students;
	}
		 
		
}


	


