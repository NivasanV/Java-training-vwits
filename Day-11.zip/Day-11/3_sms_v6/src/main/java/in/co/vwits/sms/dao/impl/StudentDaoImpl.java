package in.co.vwits.sms.dao.impl;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import in.co.vwits.sms.model.Student;
// This class is responsible for talking to(Read,Insert, Update, Delete ) 
// underline data store (in memory/database).

public class StudentDaoImpl {
	
	private List<Student> students;
	
	public StudentDaoImpl() {
		students = new ArrayList<Student>();
		Student s1= new Student();
		s1.setRollno(1);
		s1.setName("Alika");
		s1.setPercentage(99);
		s1.setNumberOfAttempts(3);
		List<String> subjects = new ArrayList<>();
		subjects.add("Python");
		subjects.add("Java");
		s1.setSubjectsLearning(subjects);
		s1.setDateOfBirth(LocalDate.of(2010, 10, 21));
		
		Student s2= new Student();
		s2.setRollno(2);
		s2.setName("Misha");
		s2.setPercentage(89);
		s2.setNumberOfAttempts(4);
		List<String> subjects1 = new ArrayList<>();
		subjects1.add("Spring");
		subjects1.add("Machine Learning");
		s2.setSubjectsLearning(subjects1);
		s2.setDateOfBirth(LocalDate.of(2011, 11, 21));
		
		Student s3= new Student();
		s3.setRollno(3);
		s3.setName("Rahul");
		s3.setPercentage(73);
		s3.setNumberOfAttempts(3);
		s3.setSubjectsLearning(subjects);
		
		
		students.add(s1);
		students.add(s2);
		students.add(s3);
	}
	public List<Student> findAll(){
		return students;
	}
	public void save(Student s) {
		students.add(s);
	}
	
	public Optional<Student> findByRollno(int rollno) {
		for(Student s:students) {
			if(s.getRollno()==rollno) {
				return Optional.of(s);				
			}
		}
		return Optional.empty();
		
		
	}
	public void deleteByRollno(int rollno) {
		
		Iterator<Student>i= students.iterator();
		while(i.hasNext()) {
			Student s= i.next();
			if(s.getRollno()==rollno) {
				i.remove();
			}
		}
		
	}
    public void updateByRollno(int rollno, double modifiedMarks) {
		for(Student s:students) {
			if(s.getRollno()==rollno) {
				s.setPercentage(modifiedMarks);
			}
		}
		
	}
    
   

}
//Read All
