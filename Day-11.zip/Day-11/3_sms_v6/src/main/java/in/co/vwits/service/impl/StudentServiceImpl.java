
package in.co.vwits.service.impl;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import in.co.vwits.model.exception.StudentNotFoundException;
import in.co.vwits.service.StudentService;
import in.co.vwits.sms.dao.StudentDao;
import in.co.vwits.sms.dao.impl.StudentDaoImpl;
import in.co.vwits.sms.dao.impl.StudentJDBCDaoImpl;
import in.co.vwits.sms.model.Student;

public class StudentServiceImpl implements StudentService {
	//Using reference of interface to communicate with other layer of applications is known as coding to interface.
	//Coding to interface is the best practice as it gives you loose coupling among layers
	private StudentDao dao;
	public StudentServiceImpl(){
		dao= new StudentJDBCDaoImpl();

	}

	//Print all who scored more than 80
	@Override
	public List<Student> findAllStudentScoreMoreThan80(double percentage){
		return dao.findAll().stream()
				.filter(student->student.getPercentage()>percentage)
				.collect(Collectors.toList());

	}
	//Print all who scored more than 80 in less than 3 attempts
	@Override
	public List<Student> findAllStudentScoreMoreThan80LesserAttempt(double percentage, int numberOfAttempts ){
		return dao.findAll().stream()
				.filter(student->student.getPercentage()>percentage && student.getNumberOfAttempts()<3)
				.collect(Collectors.toList());


	}	
	//Print all whose name starts with M

	@Override
	public long countOfStudentNameStartingWithM(String name ){ return
			dao.findAll().stream() .filter(student->student.getName().startsWith("M"))
			.count();

	}


	//Count all whose name starts with M

	@Override
	public List<Student> findAllStudentNameStartingWithM(String name ){
		return dao.findAll().stream()
				.filter(student->student.getName().startsWith("M"))
				.toList();

	}
	//Using Sorted
	@Override
	public List<Student> findAllStudentSortedByPercentage(){
		return dao.findAll().stream().sorted().collect(Collectors.toList()); 
	}
	//Score more than 90
	@Override
	public List<String> findAllStudentScoreMoreThanGivenPercentage(double Percentage){
		return dao.findAll().stream()
				.filter(student->student.getPercentage()>Percentage)
				.map(student->student.getName())
				.toList();
	}

	// Case 11: Student Learning specific subject
	@Override
	public List<Student> findAllStudentsLearningSpecificSubject(String subject){
		return dao.findAll().stream()
				.filter(student->student.getSubjectsLearning().stream().anyMatch(sub->sub.equals(subject)))
				.toList();

	}
	@Override
	public List<Student> findAllStudentsBornBeforeSpecificDate(LocalDate SpecificDate){

		return dao.findAll().stream()

				.filter(student -> student.getDateOfBirth().isBefore(SpecificDate))

				.collect(Collectors.toList());

	}	    

	@Override
	public long findStudentsCountBornAfterSpecificDate(LocalDate SpecificDate){

		return dao.findAll().stream()

				.filter(student -> student.getDateOfBirth().isAfter(SpecificDate))

				.count();

	}
	//Score more than 90
	@Override
	public Map<Boolean,List<Student>> partitioningStudentsBasedOnMarks(double marks){
		return dao.findAll().stream()
				.collect(Collectors.partitioningBy(student->student.getPercentage()>marks));

	}

	@Override
	public List<Student> findAll(){
		return dao.findAll();
	}
	@Override
	public void save(Student s) {
		dao.save(s);
	}
	//Find Case 3
	@Override
	public Optional<Student> findByRollno(int rollno) throws StudentNotFoundException {
		Optional<Student> p=dao.findByRollno(rollno);
		if(p.isPresent()) {
			return p;
		}
		else {
			// throw user defined exception "StudentNotFound"
			throw new StudentNotFoundException();
		}

	}
	@Override
	public void deleteByRollno(int rollno) {
		dao.deleteByRollno(rollno);

	}

	
	  @Override
	public void updateByRollno(int rollno, double modifiedMarks) {
	  dao.updateByRollno(rollno,modifiedMarks); }
	 
	@Override
	public long findUniqueSubject() {
		return dao.findAll().stream().flatMap(s->s.getSubjectsLearning().stream()).distinct().count();
	    //distinct gives unique elements
	}

	@Override
	public List<Student> findStudentsCountBornAfterSpecificDate(String strDate) {
		// TODO Auto-generated method stub
		return null;
	}



}
