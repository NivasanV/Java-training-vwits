package in.co.vwits.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import in.co.vwits.model.exception.StudentNotFoundException;
import in.co.vwits.sms.model.Student;

public interface StudentService {

	//Print all who scored more than 80
	List<Student> findAllStudentScoreMoreThan80(double percentage);

	//Print all who scored more than 80 in less than 3 attempts
	List<Student> findAllStudentScoreMoreThan80LesserAttempt(double percentage, int numberOfAttempts);
	//Print all whose name starts with M

	long countOfStudentNameStartingWithM(String name);

	List<Student> findAllStudentNameStartingWithM(String name);

	//Using Sorted
	List<Student> findAllStudentSortedByPercentage();

	//Score more than 90
	List<String> findAllStudentScoreMoreThanGivenPercentage(double Percentage);

	// Case 11: Student Learning specific subject
	List<Student> findAllStudentsLearningSpecificSubject(String subject);

	List<Student> findAllStudentsBornBeforeSpecificDate(LocalDate SpecificDate);

	long findStudentsCountBornAfterSpecificDate(LocalDate SpecificDate);

	//Score more than 90
	Map<Boolean, List<Student>> partitioningStudentsBasedOnMarks(double marks);

	List<Student> findAll();

	void save(Student s);

	//Find Case 3
	Optional<Student> findByRollno(int rollno) throws StudentNotFoundException;

	void deleteByRollno(int rollno);

	void updateByRollno(int rollno, double modifiedMarks);

	long findUniqueSubject();

	List<Student> findStudentsCountBornAfterSpecificDate(String strDate);

}