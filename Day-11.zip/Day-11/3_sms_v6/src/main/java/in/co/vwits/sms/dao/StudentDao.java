package in.co.vwits.sms.dao;

import java.util.List;
import java.util.Optional;

import in.co.vwits.sms.model.Student;

public interface StudentDao {
	public int save(Student s);
	public Optional<Student> findByRollno(int rollno);
	public List<Student> findAll();
	public void deleteByRollno(int rollno);
	  public void updateByRollno(int rollno, double modifiedMarks);

}
