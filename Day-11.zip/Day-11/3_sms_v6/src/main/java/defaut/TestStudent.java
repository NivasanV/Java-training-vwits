package defaut;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;

import in.co.vwits.model.exception.StudentNotFoundException;
import in.co.vwits.service.StudentService;
import in.co.vwits.service.impl.StudentServiceImpl;
import in.co.vwits.sms.model.Student;

public class TestStudent {

	public static void main(String[] args) {
		int option=1;
		Scanner sc = null;
		try {
			sc=new Scanner(System.in);
			StudentService service = new StudentServiceImpl();
		
		//Show all students
	do {
			System.out.println("Welcome to student mangement ");
			System.out.println("1 Find all records");
			System.out.println("2 Insert Records");
			System.out.println("3 Find student by Roll No.");
			System.out.println("4 Delete student by Roll No.");
			System.out.println("5 Update student by Roll No.");
			System.out.println("6 Find all who scored more than 80");
			System.out.println("7 Find all who scored more than 80 in less than 3 attempts");
			System.out.println("8 Find all whose name starts with M");
			System.out.println("9 Sort in asc order");
			System.out.println("10 Students scoring more than given percentage(90) ");
			System.out.println("11 Students learnng specific subject");
			System.out.println("-1 to Exit");
			System.out.println("Enter choice");
			
			option= sc.nextInt();
			
			switch(option) {
			case 1:
				List<Student> students = service.findAll();
			    System.out.println(students);
			    break;
			case 2:
				//
				Student s= new Student();
				s.setName("Ram");
				s.setRollno(23);
				s.setPercentage(98);
				service.save(s);
				break;
			case 3:
				System.out.println("Enter the roll no.");
				int rollno=sc.nextInt();
				Optional<Student> foundstudent;
				
				try {
					
					foundstudent = service.findByRollno(rollno);
					System.out.println("Found Student"+foundstudent.get());
				} catch (StudentNotFoundException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					System.out.println("Student Not Found");
				}
				
				break;
			case 4:
				System.out.println("Enter the roll no.");
				try {
					rollno=sc.nextInt();
					service.deleteByRollno(rollno);
				}
				catch(InputMismatchException e) {
					System.out.println("Roll number must be an Integer value");
					sc.nextLine(); //This statement is used to discard the input.
				}
			
				break;
			
			case 5:
				double modifiedPercentage;
				System.out.println("Enter the roll no.");
				rollno=sc.nextInt();
				System.out.println("Enter new percentage");
				modifiedPercentage=sc.nextDouble();
				service.updateByRollno(rollno,modifiedPercentage);
				break;
			
			case 6:
				double percentage;
				System.out.println("Enter percentage");
				percentage= sc.nextDouble();
				System.out.println(service.findAllStudentScoreMoreThan80(percentage));
				
			case 7:
				int numberOfAttempts;
				
				System.out.println("Enter percentage :");
				System.out.println("Enter number of attempts");
				percentage= sc.nextDouble();
				numberOfAttempts= sc.nextInt();
				System.out.println(service.findAllStudentScoreMoreThan80LesserAttempt(percentage, numberOfAttempts));
				
			case 8:
				String name;
				System.out.println("Enter name :");
				name= sc.toString();
				System.out.println(service.countOfStudentNameStartingWithM(name));	
				
				
				
			case 9:
				System.out.println(service.findAllStudentSortedByPercentage());
				break;
				
			case 10:
				List<String> studentNames = service.findAllStudentScoreMoreThanGivenPercentage(90);
				System.out.println("Student names who scored more thann 90 are:");
				System.out.println(studentNames);
			
			case 11:
				String givenSubject = sc.next();
				List<Student> studentsLearningSpecific = service.findAllStudentsLearningSpecificSubject(givenSubject);
				System.out.println(studentsLearningSpecific);
				break;
				//Before
			case 12: 
				System.out.println("Enter date (dd-MM-yyyy)");
			    String strDate = sc.next();
			    LocalDate date = LocalDate.parse(strDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			    List<Student> beforeStudent=service.findAllStudentsBornBeforeSpecificDate(date);
			    System.out.println(beforeStudent);
			    break;
			    //After
			case 13: 
				System.out.println("Enter date (dd-MM-yyyy");
			    strDate = sc.next();
			    LocalDate dateAfter = LocalDate.parse(strDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			    long afterStudent=service.findStudentsCountBornAfterSpecificDate(dateAfter);
			    System.out.println(afterStudent);
			    break;
			
			case 14:
				System.out.println("Enter marks");
			    Map<Boolean, List<Student>> partitioningStudentsBasedOnMarks= service.partitioningStudentsBasedOnMarks(sc.nextDouble());
			    System.out.println(partitioningStudentsBasedOnMarks);
			    
			case 15:
				System.out.println(service.findUniqueSubject());
				break;
			
				
				
			case -1:
				System.out.println("--------------------Thank You---------------------");
				break;
				
			}
			
		}while(option!=-1);
		}
		finally {
			sc.close();
		}
		
		
		
		


	}

}
